package com.bkm.worktalk;

public class UserListsDTO {
    public String email;
    public String hp;
    public String name;

    public UserListsDTO() {

    }

    public UserListsDTO(String email, String hp, String name) {
        this.email = email;
        this.hp = hp;
        this.name = name;
    }
}
