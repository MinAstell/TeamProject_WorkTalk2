package com.bkm.worktalk;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class InnerProject extends AppCompatActivity {

    private TextView tv_innerProjectName;
    private TextView tv_innerProjectExplainOpened;
    private TextView tv_innerProjectExplainClosed;
    private ArrayList<ProjectDTO> arrayList;
    public String projectName = "";
    public String projectExplain = "";

    private FirebaseDatabase database;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_innerproject);

        tv_innerProjectName = (TextView) findViewById(R.id.tv_innerProjectName);
        tv_innerProjectExplainOpened = (TextView) findViewById(R.id.tv_innerProjectExplainOpened);
        tv_innerProjectExplainClosed = (TextView) findViewById(R.id.tv_innerProjectExplainClosed);

        //DB에 저장된 프로젝트 이름, 설명을 가져옴
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        projectName = bundle.getString("projectName");
        projectExplain = bundle.getString("projectExplain");
        tv_innerProjectName.setText(projectName);
        tv_innerProjectExplainOpened.setText(projectExplain);
        tv_innerProjectExplainClosed.setText(projectExplain);

        tv_innerProjectExplainOpened.setVisibility(View.INVISIBLE);

        tv_innerProjectExplainClosed.setOnClickListener(new View.OnClickListener() { //닫힌 프로젝트 설명 클릭시 프로젝트가 열림
            @Override
            public void onClick(View v) {
                tv_innerProjectExplainOpened.setVisibility(View.VISIBLE);
                tv_innerProjectExplainClosed.setVisibility(View.INVISIBLE);
            }
        });
        tv_innerProjectExplainOpened.setOnClickListener(new View.OnClickListener() { //열린 프로젝트 설명 클릭시 프로젝트가 닫힘
            @Override
            public void onClick(View v) {
                tv_innerProjectExplainOpened.setVisibility(View.INVISIBLE);
                tv_innerProjectExplainClosed.setVisibility(View.VISIBLE);
            }
        });

    }
}